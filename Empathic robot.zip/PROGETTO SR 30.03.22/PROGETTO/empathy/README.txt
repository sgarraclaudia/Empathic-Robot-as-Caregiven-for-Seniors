VISUAL STUDIO CODE: how to run EMPATHY project

- open main directory in VS code
- open a new terminal
- write "cd empathy"
- write "py manage.py runserver"



Python 3.9 64-bit
Django 4.0.0