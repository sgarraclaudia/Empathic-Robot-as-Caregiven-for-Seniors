from ast import arg
import chunk
from http.client import responses
from platform import node
from tkinter import END
from urllib import response
from django.forms import FilePathField
from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse, JsonResponse, StreamingHttpResponse
from django.http import HttpResponseRedirect
from django.template import loader
from django.urls import reverse
from .forms import MyForm
import networkx as nx  # for drawing graphs
import matplotlib.pyplot as plt  # for drawing graphs
# for creating Bayesian Belief Networks (BBN)
from pybbn.graph.dag import Bbn
from pybbn.graph.edge import Edge, EdgeType
from pybbn.graph.jointree import EvidenceBuilder
from pybbn.graph.node import BbnNode
from pybbn.graph.variable import Variable
from pybbn.pptc.inferencecontroller import InferenceController

from datetime import datetime
import os

from django.http import HttpResponse
from wsgiref.util import FileWrapper
import mimetypes


def computational_model(nodesEv):

    Text = BbnNode(Variable(0, 'Text', ['positive', 'negative', 'neutral']), 
                [0.7,0.1,0.2,0.4,0.4,0.2,0.1,0.7,0.2,0.1,0.7,0.2,0.1,0.7,0.2,0.1,0.7,0.2,0.25,0.25,0.5]) 
 
    Face = BbnNode(Variable(1, 'Face', ['happy', 'disgust', 'sad', 'anger', 'surprise', 'fear', 'neutral']), 
                [0.8,0.0,0.0,0.0,0.0,0.0,0.2,0.0,0.0,0.0,0.0,0.8,0.0,0.2,0.0,0.8,0.0,0.0,0.0,0.0,0.2,0.0,0.0,0.0,0.0,0.0,0.8,0.2,0.0,0.0,0.8,0.0,0.0,0.0,0.2,0.0,0.0,0.0,0.8,0.0,0.0,0.2,0.2,0.0,0.2,0.0,0.0,0.0,0.6]) 
 
    Voice = BbnNode(Variable(2, 'Voice', ['happy', 'disgust', 'sad', 'anger', 'surprise', 'fear', 'neutral']), 
                    [0.8,0.0,0.0,0.0,0.0,0.0,0.2,0.0,0.0,0.0,0.0,0.8,0.0,0.2,0.0,0.8,0.0,0.0,0.0,0.0,0.2,0.0,0.0,0.0,0.0,0.0,0.8,0.2,0.0,0.0,0.8,0.0,0.0,0.0,0.2,0.0,0.0,0.0,0.8,0.0,0.0,0.2,0.2,0.0,0.2,0.0,0.0,0.0,0.6]) 
 
    ObservedEmotion = BbnNode( 
        Variable(3, 'ObservedEmotion', ['happy', 'surprise', 'disgust', 'fear', 'sad', 'anger', 'neutral']), 
        [0.1429, 0.1429, 0.1429, 0.1429, 0.1429, 0.1429, 0.1429]) 
 
    Context = BbnNode(Variable(4, 'Context', ['positive', 'neutral', 'negative']), [0.33, 0.33, 0.33]) 
 
    Event = BbnNode(Variable(5, 'Event', ['positive', 'neutral', 'negative']), [0.33, 0.33, 0.33]) 
 
    ObservedAction = BbnNode(Variable(6, 'ObservedAction', ['positive', 'neutral', 'negative']), [0.33, 0.33, 0.33]) 
 
    BEL_U_Desirable_Event = BbnNode(Variable(7, 'BEL_U_Desirable_Event', ['desirable', 'undesirable', 'neutral']), 
                                    [0.9,0.0,0.1,0.8,0.0,0.2,0.3,0.7,0.0,0.8,0.0,0.2,0.6,0.0,0.4,0.2,0.5,0.3,0.6,0.3,0.1,0.6,0.1,0.3,0.3,0.7,0.0,0.8,0.0,0.2,0.4,0.0,0.6,0.3,0.6,0.1,0.4,0.0,0.6,0.1,0.1,0.8,0.0,0.6,0.4,0.5,0.3,0.2,0.0,0.4,0.6,0.0,0.7,0.3,0.6,0.4,0.0,0.6,0.0,0.4,0.4,0.6,0.0,0.5,0.3,0.2,0.0,0.4,0.6,0.0,0.7,0.3,0.6,0.4,0.0,0.0,0.7,0.3,0.0,0.9,0.1]) 
 
    Feel_U_Mood = BbnNode( 
        Variable(8, 'Feel_U_Mood', ['anxious', 'cheerful', 'angry', 'suffering', 'disgusted', 'surprised', 'neutral']), 
        [0.0,0.9,0.0,0.0,0.0,0.1,0.0,0.0,0.6,0.2,0.2,0.0,0.0,0.0,0.0,0.8,0.0,0.0,0.0,0.0,0.2,0.0,0.4,0.0,0.0,0.0,0.6,0.0,0.0,0.0,0.2,0.2,0.0,0.6,0.0,0.0,0.0,0.0,0.0,0.0,0.6,0.4,0.0,0.4,0.0,0.0,0.6,0.0,0.0,0.0,0.0,0.2,0.2,0.6,0.0,0.0,0.0,0.0,0.0,0.0,8.0,0.8,0.2,0.5,0.3,0.0,0.2,0.0,0.0,0.0,0.6,0.0,0.0,0.4,0.0,0.0,0.0,0.6,0.0,0.0,0.2,0.0,0.0,0.2,0.0,0.0,0.0,0.4,0.0,0.0,0.6,0.2,0.0,0.0,0.8,0.0,0.0,0.0,0.0,0.0,0.0,0.7,0.0,0.0,0.3,0.0,0.3,0.7,0.0,0.0,0.0,0.0,0.0,0.0,0.9,0.1,0.0,0.0,0.0,0.0,0.0,0.7,0.0,0.0,0.0,0.3,0.0,0.7,0.0,0.0,0.0,0.0,0.3,0.0,0.0,0.0,0.7,0.0,0.0,0.3,0.0,0.1,0.0,0.1,0.0,0.0,0.8]) 
 
    BEL_R_Desirable_Event = BbnNode(Variable(9, 'BEL_R_Desirable_Event', ['desirable', 'undesirable', 'neutral']), 
                                    [0.7,0.2,0.1,0.3,0.6,0.1,0.2,0.1,0.7,0.6,0.3,0.1,0.1,0.8,0.1,0.1,0.3,0.6,0.7,0.2,0.1,0.1,0.5,0.4,0.1,0.2,0.7]) 
 
    Eval_Evidence = BbnNode(Variable(10, 'Eval_Evidence', ['false', 'true']), 
                            [0.1,0.9,0.3,0.7,0.6,0.4,0.3,0.7,0.3,0.7,0.4,0.6,0.8,0.2,0.2,0.8,0.2,0.8,0.1,0.9,0.2,0.8,0.7,0.3,0.2,0.8,0.3,0.7,0.4,0.6,0.7,0.3,0.3,0.7,0.2,0.8,0.1,0.9,0.2,0.8,0.7,0.3,0.3,0.7,0.2,0.8,0.3,0.7,0.8,0.2,0.3,0.7,0.1,0.9]) 
 
    Relationship = BbnNode(Variable(11, 'Relationship', ['positive', 'negative', 'neutral']), [0.33, 0.33, 0.33]) 
 
    Empathic = BbnNode(Variable(12, 'Empathic', ['true', 'false']), [0.5, 0.5]) 
 
    BEL_R_Mood = BbnNode(Variable(13, 'BEL_R_Mood', 
                                ['anxious', 'cheerful', 'angry', 'suffering', 'disgusted', 'surprise', 'neutral']),
        [0.7,0.0,0.0,0.2,0.0,0.0,0.1,0.1,0.0,0.2,0.0,0.0,0.0,0.7,0.0,0.0,0.5,0.2,0.0,0.0,0.3,0.0,0.0,0.3,0.0,0.0,0.0,0.7,0.6,0.0,0.0,0.1,0.0,0.0,0.3,0.3,0.0,0.0,0.0,0.0,0.0,0.7,0.0,0.7,0.0,0.0,0.0,0.2,0.1,0.0,0.4,0.0,0.0,0.0,0.0,0.6,0.0,0.3,0.1,0.0,0.6,0.0,0.0,0.0,0.0,0.2,0.0,0.6,0.0,0.2,0.0,0.6,0.0,0.0,0.0,0.0,0.4,0.0,0.2,0.0,0.0,0.2,0.0,0.6,0.0,0.0,0.7,0.2,0.0,0.0,0.1,0.0,0.0,0.4,0.0,0.0,0.0,0.6,0.0,0.2,0.5,0.0,0.0,0.0,0.3,0.0,0.0,0.2,0.0,0.0,0.0,0.8,0.0,0.0,0.6,0.0,0.0,0.0,0.4,0.0,0.0,0.4,0.0,0.0,0.0,0.6,0.2,0.0,0.0,0.8,0.0,0.0,0.0,0.0,0.0,0.0,0.4,0.0,0.0,0.6,0.0,0.4,0.0,0.3,0.0,0.0,0.3,0.0,0.3,0.0,0.2,0.0,0.0,0.5,0.0,0.0,0.0,0.6,0.0,0.0,0.4,0.0,0.0,0.0,0.4,0.0,0.0,0.6,0.0,0.0,0.0,0.0,0.7,0.0,0.3,0.0,0.0,0.0,0.0,0.3,0.0,0.7,0.0,0.4,0.0,0.0,0.3,0.0,0.3,0.0,0.3,0.0,0.0,0.2,0.0,0.5,0.0,0.0,0.0,0.0,0.6,0.0,0.4,0.0,0.0,0.0,0.0,0.4,0.0,0.6,0.0,0.0,0.0,0.0,0.0,0.7,0.3,0.0,0.0,0.0,0.0,0.0,0.4,0.6,0.0,0.2,0.0,0.0,0.4,0.3,0.1,0.0,0.1,0.0,0.0,0.3,0.1,0.5,0.0,0.0,0.0,0.0,0.0,0.6,0.4,0.0,0.0,0.0,0.0,0.0,0.4,0.6,0.0,0.2,0.0,0.2,0.0,0.0,0.6,0.0,0.1,0.0,0.1,0.0,0.0,0.8,0.0,0.2,0.5,0.0,0.0,0.0,0.3,0.0,0.1,0.2,0.0,0.0,0.0,0.7,0.0,0.4,0.3,0.0,0.0,0.0,0.3,0.0,0.1,0.1,0.0,0.0,0.0,0.8]) 
 
    Feel_R_Emotion = BbnNode(Variable(14, 'Feel_R_Emotion', ['happyFor', 'sorryFor', 'disappointment', 'neutral']), 
                            [0.0,0.4,0.6,0.0,0.4,0.0,0.6,0.0,0.0,0.2,0.8,0.0,0.0,0.4,0.6,0.0,0.0,0.2,0.8,0.0,0.0,0.0,0.6,0.4,0.0,0.0,0.7,0.3,0.0,0.2,0.6,0.2,0.2,0.0,0.6,0.2,0.0,0.0,0.6,0.4,0.0,0.2,0.6,0.2,0.0,0.2,0.6,0.2,0.0,0.0,0.6,0.4,0.0,0.0,0.3,0.7,0.0,0.4,0.6,0.0,0.0,0.6,0.4,0.0,0.0,0.2,0.8,0.0,0.0,0.4,0.6,0.0,0.0,0.4,0.6,0.0,0.0,0.4,0.6,0.0,0.0,0.2,0.2,0.6,0.0,0.8,0.0,0.2,0.9,0.0,0.0,0.1,0.0,0.7,0.2,0.1,0.0,0.8,0.0,0.2,0.0,0.7,0.2,0.1,0.8,0.0,0.0,0.2,0.1,0.1,0.0,0.8,0.0,0.8,0.0,0.2,0.9,0.0,0.0,0.1,0.0,0.7,0.2,0.1,0.0,0.9,0.0,0.1,0.0,0.7,0.2,0.1,0.6,0.0,0.0,0.4,0.1,0.1,0.0,0.8,0.0,0.8,0.0,0.2,0.0,0.0,0.8,0.2,0.0,0.7,0.2,0.1,0.0,0.8,0.0,0.2,0.0,0.7,0.2,0.1,0.0,0.8,0.0,0.2,0.0,0.6,0.0,0.4])


    Goals = BbnNode(Variable(15, 'Goals', ['consular', 'neutral', 'calm', 'encourage', 'congratulate', 'scoldUp', 'cheerUp']), 
                            [0.0,0.7,0.0,0.3,0.0,0.0,0.0,0.0,0.0,0.3,0.7,0.0,0.0,0.0,0.0,0.0,0.0,0.3,0.0,0.7,0.0,0.0,0.7,0.0,0.3,0.0,0.0,0.0,0.0,0.2,0.0,0.0,0.8,0.0,0.0,0.7,0.0,0.0,0.3,0.0,0.0,0.0,0.0,0.3,0.0,0.0,0.0,0.7,0.0,0.0,0.8,0.0,0.0,0.0,0.0,0.2,0.8,0.0,0.2,0.0,0.0,0.0,0.0,0.7,0.0,0.3,0.0,0.0,0.0,0.0,0.0,0.0,0.3,0.0,0.0,0.7,0.0,0.0,0.7,0.3,0.0,0.0,0.0,0.0,0.3,0.7,0.0,0.0,0.0,0.0,0.0,0.7,0.0,0.3,0.0,0.0,0.0,0.0,0.3,0.0,0.0,0.0,0.0,0.7,0.0,0.0,0.0,0.0,0.3,0.0,0.0,0.7,0.0,0.7,0.0,0.3,0.0,0.0,0.0,0.3,0.0,0.0,0.7,0.0,0.0,0.0,0.0,0.0,0.3,0.0,0.0,0.7,0.0,0.0,0.0,0.0,0.3,0.0,0.7,0.0,0.0,0.2,0.0,0.0,0.8,0.0,0.0,0.7,0.0,0.3,0.0,0.0,0.0,0.0,0.0,0.0,0.3,0.0,0.0,0.7,0.0,0.0,0.8,0.2,0.0,0.0,0.0,0.0,0.0,0.2,0.0,0.0,0.0,0.0,0.8,0.2,0.8,0.0,0.0,0.0,0.0,0.0,0.3,0.0,0.0,0.0,0.0,0.7,0.0,0.0,0.8,0.0,0.0,0.0,0.0,0.2])

    

    # create the network structure
    bbn = Bbn() \
        .add_node(Text) \
        .add_node(Face) \
        .add_node(Voice) \
        .add_node(ObservedEmotion) \
        .add_node(Context) \
        .add_node(Event) \
        .add_node(ObservedAction) \
        .add_node(BEL_U_Desirable_Event) \
        .add_node(Feel_U_Mood) \
        .add_node(BEL_R_Desirable_Event) \
        .add_node(Relationship) \
        .add_node(Empathic) \
        .add_node(BEL_R_Mood) \
        .add_node(Eval_Evidence) \
        .add_node(Feel_R_Emotion) \
        .add_node(Goals) \
        .add_edge(Edge(ObservedEmotion, Text, EdgeType.DIRECTED)) \
        .add_edge(Edge(ObservedEmotion, Face, EdgeType.DIRECTED)) \
        .add_edge(Edge(ObservedEmotion, Voice, EdgeType.DIRECTED)) \
        .add_edge(Edge(ObservedAction, BEL_U_Desirable_Event, EdgeType.DIRECTED)) \
        .add_edge(Edge(Event, BEL_U_Desirable_Event, EdgeType.DIRECTED)) \
        .add_edge(Edge(Context, BEL_U_Desirable_Event, EdgeType.DIRECTED)) \
        .add_edge(Edge(BEL_U_Desirable_Event, Feel_U_Mood, EdgeType.DIRECTED)) \
        .add_edge(Edge(ObservedEmotion, Feel_U_Mood, EdgeType.DIRECTED)) \
        .add_edge(Edge(Feel_U_Mood, BEL_R_Mood, EdgeType.DIRECTED)) \
        .add_edge(Edge(Relationship, BEL_R_Mood, EdgeType.DIRECTED)) \
        .add_edge(Edge(Empathic, BEL_R_Mood, EdgeType.DIRECTED)) \
        .add_edge(Edge(Event, Eval_Evidence, EdgeType.DIRECTED)) \
        .add_edge(Edge(ObservedAction, Eval_Evidence, EdgeType.DIRECTED)) \
        .add_edge(Edge(Context, Eval_Evidence, EdgeType.DIRECTED)) \
        .add_edge(Edge(Event, BEL_R_Desirable_Event, EdgeType.DIRECTED)) \
        .add_edge(Edge(Context, BEL_R_Desirable_Event, EdgeType.DIRECTED)) \
        .add_edge(Edge(BEL_R_Mood, Feel_R_Emotion, EdgeType.DIRECTED)) \
        .add_edge(Edge(BEL_R_Desirable_Event, Feel_R_Emotion, EdgeType.DIRECTED)) \
        .add_edge(Edge(Eval_Evidence, Feel_R_Emotion, EdgeType.DIRECTED)) \
        .add_edge(Edge(BEL_R_Mood, Goals, EdgeType.DIRECTED)) \
        .add_edge(Edge(Feel_R_Emotion, Goals, EdgeType.DIRECTED)) \
    \
        # convert the BBN to a join tree
    join_tree = InferenceController.apply(bbn)

    # Set node positions
    # pos = {0: (0, 2), 1: (-1, 1), 2: (0, 1), 3: (1, 1), 4: (1, 2)}

    # Set options for graph looks
    options = {
        "font_size": 16,
        "node_size": 4000,
        "node_color": "white",
        "edgecolors": "black",
        "edge_color": "blue",
        "linewidths": 5,
        "width": 3, }

    # Generate graph
    n, d = bbn.to_nx_graph()
    nx.draw(n, with_labels=True, labels=d, **options)  # pos=pos,

    # Update margins and print the graph
    ax = plt.gca()
    ax.margins(0.10)
    plt.axis("off")


    # plt.show()

    # Define a function for printing marginal probabilities
    def print_probs():
        for node in join_tree.get_bbn_nodes():
            potential = join_tree.get_bbn_potential(node)

            print("Node:", node)
            print("Values:")
            print(potential)
            print(node)
            print('----------------')


    # To add evidence of events that happened so probability distribution can be recalculated
    def evidence(ev, nod, cat, val):
        ev = EvidenceBuilder() \
            .with_node(join_tree.get_bbn_node_by_name(nod)) \
            .with_evidence(cat, val) \
            .build()
        join_tree.set_observation(ev)

    fileEvidences = open("Files/FileEvidences.txt", "w")

    if nodesEv['Face'] == 'happy' or nodesEv['Face'] == 'disgust' or nodesEv['Face'] == 'sad' or nodesEv['Face'] == 'anger' or nodesEv['Face'] == 'surprise' or nodesEv['Face'] == 'fear' or nodesEv['Face'] == 'neutral':
        evidence('ev1', 'Face', nodesEv['Face'], 1.0)
        fileEvidences.write("Face ")
        fileEvidences.write(nodesEv['Face'])
        fileEvidences.write("\n")
    else:
        fileEvidences.write("Face ")
        fileEvidences.write("none")
        fileEvidences.write("\n")

    
    if nodesEv['Voice'] == 'happy' or nodesEv['Voice'] == 'disgust' or nodesEv['Voice'] == 'sad' or nodesEv['Voice'] == 'anger' or nodesEv['Voice'] == 'surprise' or nodesEv['Voice'] == 'fear' or nodesEv['Voice'] == 'neutral':
        evidence('ev2', 'Voice', nodesEv['Voice'], 1.0)
        fileEvidences.write("Voice ")
        fileEvidences.write(nodesEv['Voice'])
        fileEvidences.write("\n")
    else:
        fileEvidences.write("Voice ")
        fileEvidences.write("none")
        fileEvidences.write("\n")

    if nodesEv['Text'] == 'positive' or nodesEv['Text'] == 'negative' or nodesEv['Text'] == 'neutral':
        evidence('ev3', 'Text', nodesEv['Text'], 1.0)
        fileEvidences.write("Text ")
        fileEvidences.write(nodesEv['Text'])
        fileEvidences.write("\n")
    else:
        fileEvidences.write("Text ")
        fileEvidences.write("none")
        fileEvidences.write("\n")
    
    if nodesEv['Context'] == 'positive' or nodesEv['Context'] == 'neutral' or nodesEv['Context'] == 'negative':
        evidence('ev4', 'Context', nodesEv['Context'], 1.0)
        fileEvidences.write("Context ")
        fileEvidences.write(nodesEv['Context'])
        fileEvidences.write("\n")
    else:
        fileEvidences.write("Context ")
        fileEvidences.write("none")
        fileEvidences.write("\n")

    if nodesEv['Event'] == 'positive' or nodesEv['Event'] == 'neutral' or nodesEv['Event'] == 'negative':
        evidence('ev5', 'Event', nodesEv['Event'], 1.0)
        fileEvidences.write("Event ")
        fileEvidences.write(nodesEv['Event']) 
        fileEvidences.write("\n")
    else:
        fileEvidences.write("Event ")
        fileEvidences.write("none")
        fileEvidences.write("\n")
    
    if nodesEv['ObservedAction'] == 'positive' or nodesEv['ObservedAction'] == 'neutral' or nodesEv['ObservedAction'] == 'negative':
        evidence('ev6', 'ObservedAction', nodesEv['ObservedAction'], 1.0)
        fileEvidences.write("ObservedAction ")
        fileEvidences.write(nodesEv['ObservedAction'])
        fileEvidences.write("\n")
    else:
        fileEvidences.write("ObservedAction ")
        fileEvidences.write("none")
        fileEvidences.write("\n")

    if nodesEv['Relationship'] == 'positive' or nodesEv['Relationship'] == 'negative' or nodesEv['Relationship'] == 'neutral':
        evidence('ev7', 'Relationship', nodesEv['Relationship'], 1.0)
        fileEvidences.write("Relationship ")
        fileEvidences.write(nodesEv['Relationship'])
        fileEvidences.write("\n")
    else:
        fileEvidences.write("Relationship ")
        fileEvidences.write("none")
        fileEvidences.write("\n")
    
    
    if nodesEv['Empathic'] == 'true' or nodesEv['Empathic'] == 'false':
        evidence('ev8', 'Empathic', nodesEv['Empathic'], 1.0)
        fileEvidences.write("Empathic ")
        fileEvidences.write(nodesEv['Empathic'])
        fileEvidences.write("\n")
    else:
        fileEvidences.write("Empathic ")
        fileEvidences.write("none")
        fileEvidences.write("\n")


    fileEvidences.close()

    '''insert an observation evidence
    evidence('ev1', 'Face', 'sad', 1.0)
    evidence('ev2', 'Voice', 'sad', 1.0)
    evidence('ev3', 'Text', 'negative', 1.0)
    evidence('ev4', 'Context', 'negative', 1.0)
    evidence('ev5', 'Event', 'positive', 1.0)
    evidence('ev6', 'ObservedAction', 'negative', 1.0)
    evidence('ev7', 'Relationship', 'positive', 1.0)
    evidence('ev8', 'Empathic', 'true', 1.0)
    '''


    # print(join_tree.get_posteriors().items()['FinalAction'])
    Text = {}
    Face = {}
    Voice = {}
    ObservedEmotion = {}
    Context = {}
    Event = {}
    ObservedAction = {}
    BEL_U_Desirable_Event = {}
    Feel_U_Mood = {}
    BEL_R_Desirable_Event = {}
    Relationship = {}
    Empathic = {}
    BEL_R_Mood = {}
    Eval_Evidence = {}
    Feel_R_Emotion = {}
    Goals = {}

    info_databases = {}



    for node, posteriors in join_tree.get_posteriors().items():
        
        if node=="Text":
            for keys in posteriors.keys():
                Text[keys]=posteriors[keys]

        if node=="Face":
            for keys in posteriors.keys():
                Face[keys]=posteriors[keys]

        if node=="Voice":
            for keys in posteriors.keys():
                Voice[keys]=posteriors[keys]

        if node=="ObservedEmotion":
            for keys in posteriors.keys():
                ObservedEmotion[keys]=posteriors[keys]


        if node=="Context":
            for keys in posteriors.keys():
                Context[keys]=posteriors[keys]

        if node=="Event":
            for keys in posteriors.keys():
                Event[keys]=posteriors[keys]


        if node=="ObservedAction":
            for keys in posteriors.keys():
                ObservedAction[keys]=posteriors[keys]


        if node=="BEL_U_Desirable_Event":
            for keys in posteriors.keys():
                BEL_U_Desirable_Event[keys]=posteriors[keys]


        if node=="Relationship":
            for keys in posteriors.keys():
                Relationship[keys]=posteriors[keys]


        if node=="Feel_U_Mood":
            for keys in posteriors.keys():
                Feel_U_Mood[keys]=posteriors[keys]


        if node=="BEL_R_Desirable_Event":
            for keys in posteriors.keys():
                BEL_R_Desirable_Event[keys]=posteriors[keys]

        if node=="Empathic":
            for keys in posteriors.keys():
                Empathic[keys]=posteriors[keys]

        if node=="BEL_R_Mood":
            for keys in posteriors.keys():
                BEL_R_Mood[keys]=posteriors[keys]

        if node=="Eval_Evidence":
            for keys in posteriors.keys():
                Eval_Evidence[keys]=posteriors[keys]

        if node=="Feel_R_Emotion":
            for keys in posteriors.keys():
                Feel_R_Emotion[keys]=posteriors[keys]

        if node=="Goals":
            for keys in posteriors.keys():
                Goals[keys]=posteriors[keys]

    info_databases["Scenario"]=nodesEv['Scenario']

    path = "robot/databases/scenario" + nodesEv['Scenario'] + "/"
    dirs = os.listdir(path)

    
    i = 0
    all_file = [] 
    
    for file in dirs:
        all_file.append(file)

    if len(all_file) > 0:
        file_scenario = open(path + all_file[len(all_file)-1], "r")
        
        for line in file_scenario:
            if i==1:
                file_line1 = line
                file_line1 = file_line1.split()
                info_databases["UserAction"]=file_line1[2]
                
            if i==2:
                file_line2 = line
                file_line2 = file_line2.split()
                info_databases["GoalSuccess"]=file_line2[2]
            
            i = i + 1    
    else:

        date = datetime.today().strftime('%d-%m-%Y')
        fileScenario = open("robot/databases/scenario" + nodesEv['Scenario'] + "/" + "scenario" + nodesEv['Scenario'] + " " + "[" + date + "]" + ".txt", "w")
        fileScenario.write("Scenario --> " + nodesEv['Scenario'] + "\n")
        fileScenario.write("UserAction --> " + "none" + "\n")
        fileScenario.write("GoalSuccess --> " + "none")
        fileScenario.close()

        info_databases["UserAction"]="none"
        info_databases["GoalSuccess"]="none"

    

    Dictionary = {}
    Dictionary["dict_Face"]=Face
    Dictionary["dict_Voice"]=Voice
    Dictionary["dict_Text"]=Text
    Dictionary["dict_ObservedEmotion"]=ObservedEmotion
    Dictionary["dict_Context"]=Context
    Dictionary["dict_Event"]=Event
    Dictionary["dict_ObservedAction"]=ObservedAction
    Dictionary["dict_BEL_U_Desirable_Event"]=BEL_U_Desirable_Event
    Dictionary["dict_Feel_U_Mood"]=Feel_U_Mood
    Dictionary["dict_BEL_R_Desirable_Event"]=BEL_R_Desirable_Event
    Dictionary["dict_Relationship"]=Relationship
    Dictionary["dict_Empathic"]=Empathic
    Dictionary["dict_BEL_R_Mood"]=BEL_R_Mood
    Dictionary["dict_Eval_Evidence"]=Eval_Evidence
    Dictionary["dict_Feel_R_Emotion"]=Feel_R_Emotion
    Dictionary["dict_Goals"]=Goals
    Dictionary["dict_info_databases"]=info_databases


    return Dictionary


def robot(request):

    return render(request, 'robot/homepage.html')

def robotGiuseppe(request):
    return render(request, 'robot/scenariGiuseppe.html')

def robotMaria(request):
    return render(request, 'robot/scenariMaria.html')

    
def robot2(request):

    def nodesEv_function():
        nodesEv={'Face':request.POST.get('Face'),
                'Voice':request.POST.get('Voice'),
                'Text':request.POST.get('Text'),
                'Context':request.POST.get('Context'),
                'Event':request.POST.get('Event'),
                'ObservedAction':request.POST.get('ObservedAction'),
                'Relationship':request.POST.get('Relationship'),
                'Empathic':request.POST.get('Empathic'),
                'Scenario': request.POST.get('Scenario'),
                'UserAction': "none",
                'GoalSuccess': "none"}

    
        return nodesEv

        
    type_scenario = request.POST.get('Scenario')
    
    nodesEv = nodesEv_function()
    dizionario = computational_model(nodesEv)
    #print(dizionario["dict_info_databases"]) 

    return render(request, 'robot/' + 'scenario' + type_scenario + '.html', dizionario)

    


def robot3(request):
   
    date = datetime.today().strftime('%d-%m-%Y')
    number_scenario = request.POST.get('PageHTML')
    user_action = request.POST.get('UserAction')
    goal_success = request.POST.get('GoalSuccess')
    
    fileScenario = open("robot/databases/scenario" + number_scenario + "/" + "scenario" + number_scenario + " " + "[" + date + "]" + ".txt", "w")
    fileScenario.truncate(0)
    fileScenario.seek(0)
    fileScenario.write("Scenario --> " + number_scenario + "\n")
    fileScenario.write("UserAction --> " + user_action + "\n")
    fileScenario.write("GoalSuccess --> " + goal_success)
    fileScenario.close()

    
    fileEvidences = open("Files/FileEvidences.txt", "r")

    i = 0

    Face = ""
    Voice = ""
    Text = ""
    Context = ""
    Event = ""
    ObservedAction = ""
    Relationship = ""
    Empathic = ""


    #fileEvidences = open("FileEvidences.txt", "r")
    for line in fileEvidences:
        if i==0:
            Face=line
        if i==1:
            Voice=line
        if i==2:
            Text=line
        if i==3:
            Context=line
        if i==4:
            Event=line
        if i==5:
            ObservedAction=line
        if i==6:
            Relationship=line
        if i==7:
            Empathic=line
        #print(i, line)
        i +=1

    fileEvidences.close()

    Face = Face.split()
    Voice = Voice.split()
    Text = Text.split()
    Context = Context.split()
    Event = Event.split()
    ObservedAction = ObservedAction.split()
    Relationship = Relationship.split()
    Empathic = Empathic.split()

    nodesEv = {Face[0]: Face[1],
                Voice[0]: Voice[1],
                Text[0]: Text[1],
                Context[0]: Context[1],
                Event[0]: Event[1],
                ObservedAction[0]: ObservedAction[1],
                Relationship[0]: Relationship[1],
                Empathic[0]: Empathic[1],
                'Scenario' : request.POST.get('PageHTML'),
                'UserAction': request.POST.get('UserAction'),
                'GoalSuccess': request.POST.get('GoalSuccess')}


    if(request.POST.get('Face'))!='':  
        nodesEv.update({Face[0]: request.POST.get('Face')})  
        
    if request.POST.get('Voice')!='':
        nodesEv.update({Voice[0]: request.POST.get('Voice')})  
    
    if(request.POST.get('Text'))!='':
        nodesEv.update({Text[0]: request.POST.get('Text')})  
    
    if(request.POST.get('Context'))!='':
        nodesEv.update({Context[0]: request.POST.get('Context')})  
    
    if(request.POST.get('Event'))!='':
        nodesEv.update({Event[0]: request.POST.get('Event')})  
    
    if(request.POST.get('ObservedAction'))!='':
        nodesEv.update({ObservedAction[0]: request.POST.get('ObservedAction')})  

    if(request.POST.get('Relationship'))!='':
        nodesEv.update({Relationship[0]: request.POST.get('Relationship')})  

    if(request.POST.get('Empathic'))!='':
        nodesEv.update({Empathic[0]: request.POST.get('Empathic')})  
    

    dizionario = computational_model(nodesEv)

    dialogo=request.POST.get('dialogo')

    fileDialogo = open("Files/dialogue.txt", "w")
    fileDialogo.write(date + "\n\n")
    fileDialogo.write(dialogo)
    fileDialogo.close()



    print('robot3-------------')
    print('Face: ', dizionario['dict_Face'])
    print('Voice: ', dizionario["dict_Voice"])
    print('Text: ', dizionario["dict_Text"])
    print('ObservedEmotion: ', dizionario["dict_ObservedEmotion"])
    print('Context: ', dizionario["dict_Context"])
    print('Event: ', dizionario["dict_Event"])
    print('ObservedAction: ', dizionario["dict_ObservedAction"])
    print('BEL_U_Desirable_Event: ', dizionario["dict_BEL_U_Desirable_Event"])
    print('Feel_U_Mood: ', dizionario["dict_Feel_U_Mood"])
    print('BEL_R_Desirable_Event: ', dizionario["dict_BEL_R_Desirable_Event"])
    print('Relationship: ', dizionario["dict_Relationship"])
    print('Empathic: ', dizionario["dict_Empathic"])
    print('BEL_R_Mood: ', dizionario["dict_BEL_R_Mood"])
    print('Eval_Evidence: ', dizionario["dict_Eval_Evidence"])
    print('Feel_R_Emotion: ', dizionario["dict_Feel_R_Emotion"])
    print('Goals: ', dizionario["dict_Goals"])

    fileLog = open("Files/FileLog.txt", "a")
    time = datetime.today().strftime("%H:%M:%S")
    fileLog.write(date + "  " + time + "\n\n")

    dict_Face=str(dizionario['dict_Face'])
    dict_Voice=str(dizionario["dict_Voice"])
    dict_Text=str(dizionario["dict_Text"])
    dict_ObservedEmotion=str(dizionario["dict_ObservedEmotion"])
    dict_Context=str(dizionario["dict_Context"])
    dict_Event=str(dizionario["dict_Event"])
    dict_ObservedAction=str(dizionario["dict_ObservedAction"])
    dict_BEL_U_Desirable_Event=str(dizionario["dict_BEL_U_Desirable_Event"])
    dict_Feel_U_Mood=str(dizionario["dict_Feel_U_Mood"])
    dict_BEL_R_Desirable_Event=str(dizionario["dict_BEL_R_Desirable_Event"])
    dict_Relationship=str(dizionario["dict_Relationship"])
    dict_Empathic=str(dizionario["dict_Empathic"])
    dict_BEL_R_Mood=str(dizionario["dict_BEL_R_Mood"])
    dict_Eval_Evidence=str(dizionario["dict_Eval_Evidence"])
    dict_Feel_R_Emotion=str(dizionario["dict_Feel_R_Emotion"])
    dict_Goals=str(dizionario["dict_Goals"])

    fileLog.write("Face" + dict_Face + "\n")
    fileLog.write("Voice" + dict_Voice + "\n")
    fileLog.write("Text" + dict_Text + "\n")
    fileLog.write("ObservedEmotion" + dict_ObservedEmotion + "\n")
    fileLog.write("Context" + dict_Context + "\n")
    fileLog.write("Event" + dict_Event + "\n")
    fileLog.write("ObservedAction" + dict_ObservedAction + "\n")
    fileLog.write("BEL_U_Desirable_Event" + dict_BEL_U_Desirable_Event + "\n")
    fileLog.write("Feel_U_Mood" + dict_Feel_U_Mood + "\n")
    fileLog.write("BEL_R_Desirable_Event" + dict_BEL_R_Desirable_Event + "\n")
    fileLog.write("Relationship" + dict_Relationship + "\n")
    fileLog.write("Empathic" + dict_Empathic + "\n")
    fileLog.write("BEL_R_Mood" + dict_BEL_R_Mood + "\n")
    fileLog.write("Eval_Evidence" + dict_Eval_Evidence + "\n")
    fileLog.write("Feel_R_Emotion" + dict_Feel_R_Emotion + "\n")
    fileLog.write("Goals" + dict_Goals + "\n\n\n")
    
    fileLog.close()



    print('-------------')
    print(dialogo)
    print('-------------')
    #return render(request, 'robot/' + 'scenario' + number_scenario + '.html', dizionario)
    return JsonResponse(dizionario)




def downloadDialogue(request):
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    filename = 'dialogue.txt'
    filepath = base_dir + "/Files/" + filename
    thefile = filepath
    filename = os.path.basename(thefile)
    chunk_size = 8192
    response = StreamingHttpResponse(FileWrapper(open(thefile, 'rb'), chunk_size),
        content_type = mimetypes.guess_type(thefile)[0])

    response['Content-Length'] = os.path.getsize(thefile)
    response['Content-Disposition'] = 'attachment; filename=%s' % filename
    return response


def downloadReport(request):
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    filename = 'FileLog.txt'
    filepath = base_dir + "/Files/" + filename
    thefile = filepath
    filename = os.path.basename(thefile)
    chunk_size = 8192
    response = StreamingHttpResponse(FileWrapper(open(thefile, 'rb'), chunk_size),
        content_type = mimetypes.guess_type(thefile)[0])

    response['Content-Length'] = os.path.getsize(thefile)
    response['Content-Disposition'] = 'attachment; filename=%s' % filename
    return response

