from django import forms

class MyForm(forms.Form):
    Relationship = (('Positive', 'Positive'),
                    ('Neutral', 'Neutral'),
                    ('Negative', 'Negative'))
    
    Empathic = (('True', 'True'),
                    ('False', 'False'))
    

    Rel = forms.ChoiceField(choices=Relationship)
    Emp = forms.ChoiceField(choices=Empathic)