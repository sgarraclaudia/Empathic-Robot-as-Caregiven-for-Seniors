from django.urls import path
from django.contrib import admin
from . import views


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.robot),
    path('Giuseppe', views.robotGiuseppe),
    path('Maria', views.robotMaria),
    path('robot2/', views.robot2),
    path('robot3/', views.robot3),
    path('downloadDialogue', views.downloadDialogue),
    path('downloadReport', views.downloadReport),

]